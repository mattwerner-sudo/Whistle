# LinkedIn → Clay Sync

Sync your LinkedIn connections to Clay with one click.

**Built by [GTMBase.io](https://gtmbase.io)**

---

## Features

- ✅ **One-click sync** - No coding required
- ✅ **Delta sync** - Only syncs new connections after first run
- ✅ **Background sync** - Close the popup, sync continues
- ✅ **Runs in your browser** - No external servers, your data stays yours

---

## Installation

### From Chrome Web Store (coming soon)
*Link will be added once published*

### Manual Install (Developer Mode)

1. Download and unzip this folder
2. Open Chrome → go to `chrome://extensions/`
3. Enable **Developer mode** (toggle in top right)
4. Click **Load unpacked**
5. Select the `linkedin-sync-extension` folder

---

## Usage

1. **Make sure you're logged into LinkedIn** in Chrome
2. Click the extension icon in your toolbar
3. It should show **"Connected"** next to LinkedIn
4. Paste your **Clay webhook URL**
5. Click **Sync Connections**

### Getting your Clay Webhook URL

1. In Clay, create a new table (or use existing)
2. Click **Sources** → **Webhook**
3. Copy the webhook URL

---

## Data Synced

Each connection is sent to your webhook with:

| Field | Description |
|-------|-------------|
| `firstName` | First name |
| `lastName` | Last name |
| `fullName` | Combined full name |
| `headline` | LinkedIn headline |
| `profileUrl` | Full LinkedIn profile URL |
| `publicIdentifier` | LinkedIn username/slug |
| `connectedAt` | When you connected (ISO date) |
| `entityUrn` | LinkedIn internal ID |

---

## Delta Sync

After your first sync, the extension remembers when you last synced.

- **Toggle ON** (default): Only sends connections added since last sync
- **Toggle OFF**: Syncs all connections every time

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Not logged in" | Go to linkedin.com and log in, then reopen extension |
| Sync stops partway | LinkedIn rate limit - wait 5 mins and retry |
| Webhook errors | Verify your Clay webhook URL is correct and active |
| No new connections | If delta sync is on and you haven't added anyone, nothing to sync! |

---

## Privacy

- **No external servers** - Everything runs in your browser
- **No data collection** - We don't see or store your connections
- **Your LinkedIn session** - Uses your existing login, no passwords shared

---

## Support

Questions? Reach out at [gtmbase.io](https://gtmbase.io)

---

## Version History

- **v2.0.0** - Background sync, delta sync, improved UI
- **v1.0.0** - Initial release

---

MIT License • Built with ♥ by [GTMBase.io](https://gtmbase.io)
