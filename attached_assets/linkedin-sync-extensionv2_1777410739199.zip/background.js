// ============================================
// LinkedIn → Clay Sync - Background Service Worker
// ============================================

const CONFIG = {
  PAGE_SIZE: 100,
  DELAY_MS: 2000,
  ANALYTICS_ENDPOINT: 'https://api.clay.com/v3/sources/webhook/pull-in-data-from-a-webhook-9524071f-5774-41f2-8b45-aadc2af3a291',
};

// ============================================
// Installation & Analytics
// ============================================

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    // Get user's LinkedIn profile
    const userProfile = await getCurrentUserProfile();
    
    await chrome.storage.local.set({ 
      userProfile,
      installedAt: new Date().toISOString(),
      version: chrome.runtime.getManifest().version
    });
    
    trackEvent('extension_installed', { userProfile });
    
  } else if (details.reason === 'update') {
    const { userProfile } = await chrome.storage.local.get(['userProfile']);
    trackEvent('extension_updated', { 
      userProfile,
      previousVersion: details.previousVersion,
      newVersion: chrome.runtime.getManifest().version
    });
  }
});

async function getCurrentUserProfile() {
  try {
    // Get cookies
    const liAtCookie = await chrome.cookies.get({
      url: 'https://www.linkedin.com',
      name: 'li_at'
    });
    
    const jsessionCookie = await chrome.cookies.get({
      url: 'https://www.linkedin.com',
      name: 'JSESSIONID'
    });

    if (!liAtCookie?.value) {
      return null;
    }

    const csrfToken = jsessionCookie?.value?.replace(/"/g, '') || '';

    // Fetch current user's profile
    const response = await fetch('https://www.linkedin.com/voyager/api/me', {
      headers: {
        'cookie': `li_at=${liAtCookie.value}; JSESSIONID="${csrfToken}"`,
        'csrf-token': csrfToken,
        'x-restli-protocol-version': '2.0.0',
        'x-li-lang': 'en_US',
      },
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    
    // Extract useful profile info
    return {
      firstName: data.firstName || '',
      lastName: data.lastName || '',
      fullName: `${data.firstName || ''} ${data.lastName || ''}`.trim(),
      headline: data.headline || '',
      publicIdentifier: data.publicIdentifier || data.miniProfile?.publicIdentifier || '',
      profileUrl: data.publicIdentifier 
        ? `https://www.linkedin.com/in/${data.publicIdentifier}`
        : '',
      entityUrn: data.entityUrn || '',
    };
  } catch (e) {
    console.log('Could not fetch user profile:', e);
    return null;
  }
}

async function trackEvent(eventName, data = {}) {
  if (!CONFIG.ANALYTICS_ENDPOINT) return;
  
  try {
    // Get user profile if not already in data
    let userProfile = data.userProfile;
    if (!userProfile) {
      const stored = await chrome.storage.local.get(['userProfile']);
      userProfile = stored.userProfile;
      
      // If still no profile (not logged in at install), try to get it now
      if (!userProfile) {
        userProfile = await getCurrentUserProfile();
        if (userProfile) {
          await chrome.storage.local.set({ userProfile });
        }
      }
    }
    
    await fetch(CONFIG.ANALYTICS_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: eventName,
        userProfile: userProfile || { fullName: 'Unknown', profileUrl: '' },
        timestamp: new Date().toISOString(),
        version: chrome.runtime.getManifest().version,
        ...data
      })
    });
  } catch (e) {
    // Silent fail - don't break functionality for analytics
    console.log('Analytics error:', e);
  }
}

// ============================================
// Sync State Management
// ============================================

let syncState = {
  isRunning: false,
  progress: 0,
  progressText: '',
  error: null,
  result: null
};

function updateSyncState(updates) {
  syncState = { ...syncState, ...updates };
  // Broadcast to popup if open
  chrome.runtime.sendMessage({ type: 'SYNC_STATE_UPDATE', state: syncState }).catch(() => {
    // Popup not open, ignore
  });
}

// ============================================
// Message Handling from Popup
// ============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_SYNC') {
    handleStartSync(message.webhookUrl, message.deltaSync, message.lastSyncTime);
    sendResponse({ started: true });
  }
  
  if (message.type === 'GET_SYNC_STATE') {
    sendResponse(syncState);
  }
  
  if (message.type === 'TRACK_EVENT') {
    trackEvent(message.eventName, message.data);
    sendResponse({ tracked: true });
  }
  
  return true; // Keep channel open for async response
});

// ============================================
// Sync Logic
// ============================================

async function handleStartSync(webhookUrl, deltaSync, lastSyncTime) {
  if (syncState.isRunning) return;
  
  updateSyncState({
    isRunning: true,
    progress: 0,
    progressText: 'Starting sync...',
    error: null,
    result: null
  });

  const syncStartTime = new Date().toISOString();

  try {
    // Get cookies
    const liAtCookie = await chrome.cookies.get({
      url: 'https://www.linkedin.com',
      name: 'li_at'
    });
    
    const jsessionCookie = await chrome.cookies.get({
      url: 'https://www.linkedin.com',
      name: 'JSESSIONID'
    });

    if (!liAtCookie?.value) {
      throw new Error('Not logged into LinkedIn');
    }

    const csrfToken = jsessionCookie?.value?.replace(/"/g, '') || '';

    // Fetch all connections
    let connections = await fetchAllConnections(csrfToken);
    
    trackEvent('sync_fetched', { totalConnections: connections.length });

    // Filter to only new connections if delta sync is enabled
    let filteredConnections = connections;
    
    if (deltaSync && lastSyncTime) {
      const lastSync = new Date(lastSyncTime);
      filteredConnections = connections.filter(c => {
        if (!c.connectedAt) return false;
        return new Date(c.connectedAt) > lastSync;
      });
      
      updateSyncState({
        progress: 90,
        progressText: `Found ${filteredConnections.length} new connections...`
      });
    }

    if (filteredConnections.length === 0) {
      updateSyncState({
        isRunning: false,
        progress: 100,
        progressText: 'Complete!',
        result: { success: true, message: '✓ No new connections to sync!', count: 0 }
      });
      
      trackEvent('sync_completed', { newConnections: 0, totalConnections: connections.length });
    } else {
      // Send to webhook
      await sendToWebhook(filteredConnections, webhookUrl);
      
      const message = `✓ Synced ${filteredConnections.length} ${deltaSync && lastSyncTime ? 'new ' : ''}connections to Clay!`;
      
      updateSyncState({
        isRunning: false,
        progress: 100,
        progressText: 'Complete!',
        result: { success: true, message, count: filteredConnections.length }
      });
      
      trackEvent('sync_completed', { 
        newConnections: filteredConnections.length, 
        totalConnections: connections.length 
      });
    }

    // Save last sync time
    await chrome.storage.local.set({ lastSyncTime: syncStartTime });

  } catch (error) {
    updateSyncState({
      isRunning: false,
      progress: 0,
      error: error.message,
      result: { success: false, message: `Error: ${error.message}` }
    });
    
    trackEvent('sync_error', { error: error.message });
  }
}

async function fetchAllConnections(csrfToken) {
  let allConnections = [];
  let start = 0;
  let hasMore = true;
  let totalEstimate = null;

  while (hasMore) {
    updateSyncState({
      progressText: `Fetching connections (${allConnections.length} so far)...`
    });

    const data = await fetchConnectionsPage(start, csrfToken);

    if (totalEstimate === null && data.paging) {
      totalEstimate = data.paging.total || 1000;
    }

    const elements = data.elements || [];
    const parsed = elements.map(parseConnection).filter(c => c !== null);

    allConnections = allConnections.concat(parsed);

    const percent = Math.min((allConnections.length / (totalEstimate || 1000)) * 80, 80);
    updateSyncState({
      progress: percent,
      progressText: `Fetched ${allConnections.length} connections...`
    });

    hasMore = elements.length === CONFIG.PAGE_SIZE;
    start += CONFIG.PAGE_SIZE;

    if (hasMore) {
      await sleep(CONFIG.DELAY_MS);
    }
  }

  return allConnections;
}

async function fetchConnectionsPage(start, csrfToken) {
  const url = `https://www.linkedin.com/voyager/api/relationships/dash/connections?decorationId=com.linkedin.voyager.dash.deco.web.mynetwork.ConnectionListWithProfile-16&count=${CONFIG.PAGE_SIZE}&q=search&start=${start}`;

  const liAtCookie = await chrome.cookies.get({
    url: 'https://www.linkedin.com',
    name: 'li_at'
  });

  const response = await fetch(url, {
    headers: {
      'cookie': `li_at=${liAtCookie.value}; JSESSIONID="${csrfToken}"`,
      'csrf-token': csrfToken,
      'x-restli-protocol-version': '2.0.0',
      'x-li-lang': 'en_US',
    },
  });

  if (!response.ok) {
    throw new Error(`LinkedIn API error: ${response.status}`);
  }

  return response.json();
}

function parseConnection(element) {
  try {
    const profile = element.connectedMemberResolutionResult || {};
    return {
      firstName: profile.firstName || '',
      lastName: profile.lastName || '',
      fullName: `${profile.firstName || ''} ${profile.lastName || ''}`.trim(),
      headline: profile.headline || '',
      profileUrl: profile.publicIdentifier
        ? `https://www.linkedin.com/in/${profile.publicIdentifier}`
        : '',
      publicIdentifier: profile.publicIdentifier || '',
      connectedAt: element.createdAt ? new Date(element.createdAt).toISOString() : '',
      entityUrn: profile.entityUrn || '',
    };
  } catch (e) {
    return null;
  }
}

async function sendToWebhook(connections, webhookUrl) {
  updateSyncState({
    progress: 85,
    progressText: 'Sending to Clay...'
  });

  for (let i = 0; i < connections.length; i++) {
    const connection = connections[i];

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(connection),
    });

    if (!response.ok) {
      throw new Error(`Webhook error: ${response.status}`);
    }

    if (i % 10 === 0 || i === connections.length - 1) {
      const percent = 85 + ((i / connections.length) * 15);
      updateSyncState({
        progress: percent,
        progressText: `Sent ${i + 1}/${connections.length} to Clay...`
      });
    }

    await sleep(100);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
