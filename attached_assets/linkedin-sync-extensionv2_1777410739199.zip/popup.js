// ============================================
// LinkedIn → Clay Sync - Popup UI
// ============================================

// DOM Elements
const linkedinStatusDot = document.getElementById('linkedin-status-dot');
const linkedinStatusText = document.getElementById('linkedin-status-text');
const webhookInput = document.getElementById('webhook-url');
const syncBtn = document.getElementById('sync-btn');
const progressContainer = document.getElementById('progress-container');
const progressBar = document.getElementById('progress-bar');
const progressText = document.getElementById('progress-text');
const resultDiv = document.getElementById('result');
const deltaSyncToggle = document.getElementById('delta-sync');
const lastSyncInfo = document.getElementById('last-sync-info');

// State
let lastSyncTime = null;

// ============================================
// Initialization
// ============================================

async function init() {
  // Load saved settings
  const stored = await chrome.storage.local.get(['webhookUrl', 'lastSyncTime', 'deltaSync']);

  if (stored.webhookUrl) {
    webhookInput.value = stored.webhookUrl;
  }

  if (stored.lastSyncTime) {
    lastSyncTime = stored.lastSyncTime;
    updateLastSyncDisplay(lastSyncTime);
  } else {
    lastSyncInfo.textContent = 'Never synced before - will sync all connections';
  }

  if (stored.deltaSync !== undefined) {
    deltaSyncToggle.checked = stored.deltaSync;
  }

  // Check LinkedIn connection
  await checkLinkedInStatus();

  // Check if sync is already running
  const syncState = await chrome.runtime.sendMessage({ type: 'GET_SYNC_STATE' });
  if (syncState && syncState.isRunning) {
    showSyncInProgress(syncState);
  } else if (syncState && syncState.result) {
    showResult(syncState.result.success ? 'success' : 'error', syncState.result.message);
  }

  // Save webhook URL on change
  webhookInput.addEventListener('input', () => {
    chrome.storage.local.set({ webhookUrl: webhookInput.value });
    updateSyncButton();
    
    // Track webhook configured
    if (webhookInput.value.includes('clay.com')) {
      chrome.runtime.sendMessage({ 
        type: 'TRACK_EVENT', 
        eventName: 'webhook_configured',
        data: { provider: 'clay' }
      });
    }
  });

  // Save delta sync preference on change
  deltaSyncToggle.addEventListener('change', () => {
    chrome.storage.local.set({ deltaSync: deltaSyncToggle.checked });
  });

  // Sync button click
  syncBtn.addEventListener('click', startSync);

  // Listen for sync state updates from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'SYNC_STATE_UPDATE') {
      handleSyncStateUpdate(message.state);
    }
  });
}

function updateLastSyncDisplay(timestamp) {
  const date = new Date(timestamp);
  lastSyncInfo.textContent = `Last synced: ${date.toLocaleDateString()} at ${date.toLocaleTimeString()}`;
}

async function checkLinkedInStatus() {
  try {
    const cookie = await chrome.cookies.get({
      url: 'https://www.linkedin.com',
      name: 'li_at'
    });

    if (cookie && cookie.value) {
      linkedinStatusDot.classList.add('connected');
      linkedinStatusDot.classList.remove('disconnected');
      linkedinStatusText.textContent = 'Connected';
      updateSyncButton();
    } else {
      throw new Error('Not logged in');
    }
  } catch (error) {
    linkedinStatusDot.classList.add('disconnected');
    linkedinStatusDot.classList.remove('connected');
    linkedinStatusText.textContent = 'Not logged in';
    syncBtn.disabled = true;
  }
}

function updateSyncButton() {
  const hasWebhook = webhookInput.value.trim().startsWith('https://');
  const isConnected = linkedinStatusDot.classList.contains('connected');
  syncBtn.disabled = !(hasWebhook && isConnected);
}

// ============================================
// Sync Control
// ============================================

async function startSync() {
  const webhookUrl = webhookInput.value.trim();

  if (!webhookUrl) {
    showResult('error', 'Please enter a webhook URL');
    return;
  }

  // Send sync request to background worker
  chrome.runtime.sendMessage({
    type: 'START_SYNC',
    webhookUrl,
    deltaSync: deltaSyncToggle.checked,
    lastSyncTime
  });

  // Update UI
  showSyncInProgress({ progress: 0, progressText: 'Starting sync...' });
}

function showSyncInProgress(state) {
  syncBtn.disabled = true;
  syncBtn.textContent = 'Syncing...';
  progressContainer.classList.add('active');
  resultDiv.className = 'result';
  resultDiv.style.display = 'none';
  
  updateProgress(state.progress, state.progressText);
}

function handleSyncStateUpdate(state) {
  if (state.isRunning) {
    showSyncInProgress(state);
  } else {
    // Sync finished
    syncBtn.disabled = false;
    syncBtn.textContent = 'Sync Connections';
    progressContainer.classList.remove('active');

    if (state.result) {
      showResult(state.result.success ? 'success' : 'error', state.result.message);
    }

    // Refresh last sync time
    chrome.storage.local.get(['lastSyncTime']).then(({ lastSyncTime: newTime }) => {
      if (newTime) {
        lastSyncTime = newTime;
        updateLastSyncDisplay(newTime);
      }
    });
  }
  
  updateProgress(state.progress, state.progressText);
}

// ============================================
// UI Helpers
// ============================================

function updateProgress(percent, text) {
  progressBar.style.width = `${percent}%`;
  if (text) progressText.textContent = text;
}

function showResult(type, message) {
  resultDiv.className = `result ${type}`;
  resultDiv.textContent = message;
  resultDiv.style.display = 'block';
}

// Start
init();
